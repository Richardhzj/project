/*sound.h*/

#define TIMER 20000
#define AUDIOBUFSIZE 128

FATFS Fatfs;		/* File system object */
FIL fid;		/* File object */
BYTE Buff[512];		/* File read buffer */
int ret;

struct ckhd {
  uint32_t ckID;
  uint32_t cksize;
};

struct fmtck {
  uint16_t wFormatTag;      
  uint16_t nChannels;
  uint32_t nSamplesPerSec;
  uint32_t nAvgBytesPerSec;
  uint16_t nBlockAlign;
  uint16_t wBitsPerSample;
};

extern uint8_t Audiobuf[AUDIOBUFSIZE];
extern int audioplayerHalf;
extern int audioplayerWhole;


void readckhd(FIL *fid, struct ckhd *hd, uint32_t ckID);

//void die (FRESULT rc);

int sound_play_selected_file(char *filename);

void sound_hit();

void sound_start();

void sound_end_win();

void sound_end_lose();
