/*score.c*/

#include "score.h"
#include <stdio.h>


// where to pass in score
int score(int score) { //pass the score in
	int high_score;
	high_score = cmp_score(score); // compare the previous highest score and curr score return the highest one
	put_score(high_score);
	return high_score;
	}
	


int cmp_score(int score) { 
  printf("cmp score start");
  // read the score from the SD card
  // FILE 
   FILE *rf;
   rf = fopen ("score.txt", "r");
   printf("open score.txt");
   int i = 0;
   fscanf(rf, "%d", &i);
   fclose(rf);
   // compare score
   if (i > score)
     {
       printf("cmp score end");
     return i; 
     } else {
     return score;
     }
   
 } // end of the cmp_score
	
	
	
	
//write to the txt file
void put_score(int high_score){	// how to erase the previous score and write on the same space of file?   
  
  printf("\n write the new high score in the score.txt\n");
  FILE *pf;
  pf = fopen ("score.txt","w");
  fprintf(pf, "%d" ,&high_score);
  fclose(pf);	
  printf("put score");
}   // end of the put_score



/*  end of the file*/

