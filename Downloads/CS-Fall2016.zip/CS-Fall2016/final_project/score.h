/* score */



int score(int);
int cmp_score(int);
void put_score(int);
