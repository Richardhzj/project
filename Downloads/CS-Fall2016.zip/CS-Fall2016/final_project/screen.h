
/*
// BMP file structures
struct bmpfile_magic{
  unsigned char magic[2]; 
};

struct bmpfile_header{
  uint32_t filesz;
  uint16_t creator1;
  uint16_t creator2;
  uint32_t bmp_offset; 
};

typedef struct {
  unit32_t header_sz;
  int32_t width;
  int32_t height;
  uint16_t nplanes;
  uint16_t bitspp;
  unit32_t compress_type;
  unit32_t bmp_bytesz;
  int32_t hres;
  int32_t vres;
  uint32_t ncolors;
  uint32_t nimpcolots;
} BITMAPINFOHERDER; 


struct bmppoxel { //little endian byte order
  uint8_t b;
  uint8_t g;
  uint8_t r;

}
*/

//uint16_t convertColor(bmppixel*);

void truncateImageBottom();

void readHeaders();

void die (FRESULT rc);

void find_slot(int);

void screen_helper(char*, int, int, int, int);

void screen_helper_2(char*);

void screen_game_start();

void screen_game_end();

void screen_hamster(int);

void screen_hammer(int);

void screen_hammer_hamster(int);

void screen_hamster_hit(int);

void screen_recover_slot(int);

void screen_header();

void screen_miss();

void screen_miss_fix();

void scree_score_fix();

void screen_score(int);

void screen_highest_score(int,int);

void screen_win();

void screen_lose();


