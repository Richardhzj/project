
/* Code: */


#include <stm32f30x.h>  // Pull in include files for F30x standard drivers
#include <f3d_led.h>     // Pull in include file for the local drivers
#include <f3d_uart.h>
#include <f3d_gyro.h>
#include <f3d_lcd_sd.h>
#include <f3d_i2c.h>
#include <f3d_accel.h>
#include <f3d_mag.h>
#include <f3d_nunchuk.h>
#include <f3d_rtc.h>
#include <f3d_systick.h>
#include <f3d_delay.h>
#include <ff.h>
#include <diskio.h>
#include <math.h> 
#include <queue.h>
#include <stdlib.h>
#include <string.h>
#include <f3d_user_btn.h>
#include "score.h"
#include "sound.h"
#include "screen.h"
#include <stdio.h> 


void inits() {
	printf("init");
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);

	f3d_delay_init();
	delay(10);
	f3d_uart_init();
	delay(10);
	f3d_lcd_init();
	delay(10);
	f3d_i2c1_init();
	delay(10);
	f3d_accel_init();
	delay(10);
	f3d_nunchuk_init();
	delay(10);
	f3d_timer2_init();
	delay(10);
	f3d_dac_init();
	delay(10);
	f3d_rtc_init();
	delay(10);
	f3d_systick_init();
}

// hammer moves
int hammer_move_right(hammer_position){
		int hamm;
		switch(hammer_position){
		 case 3:
			hamm = 1;
			break;
		case 6:
			hamm = 4;
			break;
		case 9:
			hamm = 7;
			break;
		default:
			hamm = hammer_position + 1;
		}
	return hamm;
}


int hammer_move_left(hammer_position){
	int hamm;
		switch(hammer_position){
		 case 1:
			hamm = 3;
			break;
		case 4:
			hamm = 6;
			break;
		case 7:
			hamm = 9;
			break;
		default:
			hamm = hammer_position - 1;
		}
	return hamm;
}
 
 int hammer_move_down(hammer_position){
	 int hamm;
	 switch(hammer_position){
	 case 7:
		 hamm = 1;
		 break;
	 case 8:
		 hamm = 2;
		 break;
	 case 9:
		 hamm = 3;
		 break;
	 default:
		 hamm = hammer_position + 3;
	 }
	 return hamm;
}

 int hammer_move_up(hammer_position){
	 int hamm;
	 switch(hammer_position){
	 case 1:
		 hamm = 7;
		 break;
	 case 2:
		 hamm = 8;
		 break;
	 case 3:
		 hamm = 9;
		 break;
	 default:
		 hamm = hammer_position - 3;
	 }
	return hamm;
 } // end of hammer moves



//============================================== main()


int main(void){
	
	inits(); // initializations
	printf("intifinish\n");
	delay(10);
	screen_game_start();
	//sound_start();
	delay(100);
	screen_hammer( 1 ); // show position of the hammer on the screen at slot #1
	//screen_header();
	
	int tmp = 0;
	int hammer_position = 1;
	int prev_hammer_position = hammer_position;  
	int hamster_position = 0;
	int prev_hamster_position = hamster_position;
	int curr_score = 0;
    int pre_score = curr_score;
	int game_round = 60; // hamster show 20 times
	int high_score = 0;
	int record = 0;


	//========================== while(1)  
       	
	while(1){
	 
		//hamster_position = ( rand() % 80 / 10) + 1; // #1~9   ?
	  // screen_hamster(hamster_position);
		hamster_position = (rand() % 8) + 1; 
		//printf("hamster position = %d \n", hamster_position);
		screen_hamster( hamster_position ); // show the hamster on the screen
		
		// move the hammer 
		nunchuk_t data;
		f3d_nunchuk_read(&data);
		delay(100); 
		
		if( data.jx >= 250) { 
			printf("hammer move right");
			hammer_position = hammer_move_right(hammer_position);
			screen_recover_slot( prev_hammer_position); // recover previous hammer screen
			prev_hammer_position = hammer_position; // pre_hammer move to curr
			if (hammer_position == hamster_position) {
			 	screen_hammer_hamster(hammer_position);
			} else {
				screen_hammer(hammer_position);
			}
		}

	 	if( data.jy >= 250) { 
			printf("hammer move up");
			hammer_position = hammer_move_up(hammer_position); // ?
			screen_recover_slot( prev_hammer_position); 
			prev_hammer_position = hammer_position;
			if (hammer_position == hamster_position) {
				screen_hammer_hamster(hammer_position);
			} else {
			screen_hammer(hammer_position);
			}
		}

		if( data.jx <= 5 ) { 
			printf("hammer move left");
			hammer_position = hammer_move_left(hammer_position);
			screen_recover_slot( prev_hammer_position);
			prev_hammer_position = hammer_position;
			if (hammer_position == hamster_position) {
				screen_hammer_hamster(hammer_position);
			} else {
			screen_hammer(hammer_position);
			}
		}

 		if( data.jy <= 5 ) {  
			printf("hammer move down");
			hammer_position = hammer_move_down(hammer_position); // ??????????
			screen_recover_slot( prev_hammer_position);
			prev_hammer_position = hammer_position;
			if ( hammer_position == hamster_position ) {
				screen_hammer_hamster( hammer_position );
			} else {
				screen_hammer( hammer_position );
			}
		}


		
 // when c button pressed && , check if the hamster position and the hammer position are the same
		 if ( ( data.c == 1 ) && ( hammer_position == hamster_position ) ) {
				 screen_score_fix(curr_score);
				 curr_score = curr_score + 1; 
				 screen_score(curr_score);
				 screen_hamster_hit(hammer_position);
				 printf("hit the hamster!! curr_score = %d ", curr_score);
				 screen_recover_slot(hammer_position);
				 delay(50);
				} else {
					printf("miss :( ");
					screen_miss();
					delay(10);
					screen_miss_fix();
					screen_recover_slot(hamster_position);
				//  hamster_position = 0; // re-init
				//	prev_hamster_position = hamster_position;
		 }
 
			game_round = game_round -1 ;
		if ( game_round == 0 ) {
				break; // break while(1)
		}
	} // end while(1)   
		
		
	// hight_score = score(curr_score);	
	screen_game_end(); // remind game end 
	delay(100);
	if ( high_score <= curr_score ){
		 screen_highest_score(curr_score,curr_score);
		 delay(100);
		 screen_win();
		 //sound_win();
	} else {
		 screen_highest_score(high_score,curr_score);
		 delay(100);
		 screen_lose();
		 // sound_lose();
	} 

} // end main()






// end of file
#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
	/* Infinite loop */
	/* Use GDB to find out why we're here */
	while (1);
}
#endif


/* main.c ends here */
