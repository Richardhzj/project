/* sound.c
play the sound*/




#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <f3d_led.h>     // Pull in include file for the local drivers
#include <f3d_uart.h>
#include <f3d_gyro.h>
#include <f3d_lcd_sd.h>
#include <f3d_i2c.h>
#include <f3d_accel.h>
#include <f3d_mag.h>
#include <f3d_nunchuk.h>
#include <f3d_rtc.h>
#include <f3d_systick.h>
#include <ff.h>
#include <diskio.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <queue.h>
#include <string.h>
#include <f3d_user_btn.h>
#include "sound.h"



void readckhd(FIL *fid, struct ckhd *hd, uint32_t ckID) {
  f_read(fid, hd, sizeof(struct ckhd), &ret);
  if (ret != sizeof(struct ckhd)) {
    printf("po, exiting\n");
    exit(-1);
  }
  if (ckID && (ckID != hd->ckID)) {
    printf("ckID && (ckID != hd->ckID)\n");
    exit(-1);
  }
}

/*
void die (FRESULT rc) {
  printf("Failed with rc=%u.\n", rc);
  while (1);
}
*/

int sound_play_selected_file(char *filename) {
  FRESULT rc;			/* Result code */
  DIR dir;			/* Directory object */
  FILINFO fno;			/* File information object */
  UINT bw, br;
  unsigned int retval;
  int bytesread;

  printf("\nOpen %s\n", filename);
  rc = f_open(&fid, filename, FA_READ);
  printf("opened file with rc: %d\n", rc);

  if (!rc) {
    printf("Success opening sound file\n");
    struct ckhd hd;
    uint32_t  waveid;
    struct fmtck fck;

    readckhd(&fid, &hd, 'FFIR');

    f_read(&fid, &waveid, sizeof(waveid), &ret);
    if ((ret != sizeof(waveid)) || (waveid != 'EVAW'))
      return -1;

    readckhd(&fid, &hd, ' tmf');

    f_read(&fid, &fck, sizeof(fck), &ret);

    // skip over extra info

    if (hd.cksize != 16) {
      printf("extra header info %d\n", hd.cksize - 16);
      f_lseek(&fid, hd.cksize - 16);
    }
    
    // now skip all non-data chunks !
    while(1){
      printf("skipping all non-data chunks\n");
      readckhd(&fid, &hd, 0);
      if (hd.ckID == 'atad')
        break;
      f_lseek(&fid, hd.cksize);
    }

    printf("skipped all non-data chuncks\n");

    f_read(&fid, Audiobuf, AUDIOBUFSIZE, &ret);
    hd.cksize -= ret;
    //audioplayerStart(fck.nSamplesPerSec); 
    audioplayerStart();
    while (hd.cksize) {
      int next = hd.cksize > AUDIOBUFSIZE/2 ? AUDIOBUFSIZE/2 : hd.cksize;
      if (audioplayerHalf) {
        if (next < AUDIOBUFSIZE/2)
          bzero(Audiobuf, AUDIOBUFSIZE/2);
        f_read(&fid, Audiobuf, next, &ret);
        hd.cksize -= ret;
        audioplayerHalf = 0;
      }
      if (audioplayerWhole) {
        if (next < AUDIOBUFSIZE/2)
          bzero(&Audiobuf[AUDIOBUFSIZE/2], AUDIOBUFSIZE/2);
        f_read(&fid, &Audiobuf[AUDIOBUFSIZE/2], next, &ret);
        hd.cksize -= ret;
        audioplayerWhole = 0;
      }
    }
    audioplayerStop();
  }
  printf("\nClose the file.\n");
  rc = f_close(&fid);
  if (rc) die(rc);
  return 0;
}

void sound_hit(){
   sound_play_selected_file("one.wav" );
}

void sound_start(){
  sound_play_selected_file( "one.wav" );
}

void sound_end_win(){
   sound_play_selected_file( "one.wav" );
}

void sound_end_lose(){
  sound_play_selected_file( "one.wav") ;
}


/*  end of the file*/
