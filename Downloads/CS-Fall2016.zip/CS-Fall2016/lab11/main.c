/* main.c --- 
 * 
 * Filename: main.c
 * Description: 
 * Author: Samuel Eleftheri - selefthe
           Jun Wang - wang314
 * Maintainer: 
 * Created: Thu Jan 10 11:23:43 2013
 * Last-Updated: 
 *           By: 
 *     Update #: 0
 * Keywords: 
 * Compatibility: 
 * 
 */

/* Commentary: 
 * 
 * 
 * 
 */

/* Change log:
 * 
 * 
 */
/* Code: */

#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <f3d_led.h>     // Pull in include file for the local drivers
#include <f3d_uart.h>
#include <f3d_gyro.h>
#include <f3d_lcd_sd.h>
#include <f3d_i2c.h>
#include <f3d_accel.h>
#include <f3d_mag.h>
#include <f3d_nunchuk.h>
#include <f3d_rtc.h>
#include <f3d_systick.h>
#include <ff.h>
#include <diskio.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <f3d_user_btn.h>

#define TIMER 20000
#define AUDIOBUFSIZE 128

FATFS Fatfs;		/* File system object */
FIL fid;		/* File object */
BYTE Buff[512];		/* File read buffer */
int ret;

const char *b[1];
int mode = 0;

extern uint8_t Audiobuf[AUDIOBUFSIZE];
extern int audioplayerHalf;
extern int audioplayerWhole;

struct ckhd {
  uint32_t ckID;
  uint32_t cksize;
};

struct fmtck {
  uint16_t wFormatTag;      
  uint16_t nChannels;
  uint32_t nSamplesPerSec;
  uint32_t nAvgBytesPerSec;
  uint16_t nBlockAlign;
  uint16_t wBitsPerSample;
};

void readckhd(FIL *fid, struct ckhd *hd, uint32_t ckID) {
  f_read(fid, hd, sizeof(struct ckhd), &ret);
  if (ret != sizeof(struct ckhd))
    exit(-1);
  if (ckID && (ckID != hd->ckID))
    exit(-1);
}

void die (FRESULT rc) {
  printf("Failed with rc=%u.\n", rc);
  while (1);
}

int main(void) { 

  FRESULT rc;			// Result code 
  DIR dir;			// Directory object 
  FILINFO fno;			// File information object 
  UINT bw, br;
  unsigned int retval;
  int bytesread;

  int song = 0;
  nunchuk_t numnum;
  int cursor = 40;

  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);

  f3d_uart_init();
  f3d_timer2_init();
  f3d_dac_init();
  f3d_delay_init();
  f3d_rtc_init();
  f3d_systick_init();
  f3d_lcd_init();
  f3d_i2c1_init();
  f3d_nunchuk_init();

  // LCD Display Setup
  f3d_lcd_fillScreen(BLACK);
  
  f3d_lcd_drawString(5, 10, "Choose A Wav File", WHITE, BLACK);
  f3d_lcd_drawString(20, 40, "Thermo", WHITE, BLACK);
  f3d_lcd_drawString(20, 80, "start", WHITE, BLACK);
  f3d_lcd_drawString(20, 120, "ammas", WHITE, BLACK);

  f3d_lcd_drawChar(10, cursor, 'o', WHITE, BLACK);
  //-----------------------
  
  f_mount(0, &Fatfs);// Register volume work area 

  while(1) {
    f3d_nunchuk_read(&numnum);

    while (numnum.c == 0) { // Press C to Play Sound    
      f3d_nunchuk_read(&numnum);
      if (numnum.jy < 64 && song < 2) { // Nunchuk JoyStick Y Down
	f3d_lcd_drawChar(10, cursor, 'o', BLACK, BLACK); // removes old o
	cursor = cursor + 40;
	f3d_lcd_drawChar(10, cursor, 'o', WHITE, BLACK); // places new o
	song++; // next song
	while (numnum.jy < 64) { // stays until joystick moves back
	  f3d_nunchuk_read(&numnum); 
	}
      }
      else {
        
      }

      if (numnum.jy > 192 && song > 0) { // Nunchuk JoyStick Y Up
	f3d_lcd_drawChar(10, cursor, 'o', BLACK, BLACK);
	cursor = cursor - 40;
	f3d_lcd_drawChar(10, cursor, 'o', WHITE, BLACK);
	song--;
	while (numnum.jy > 192) {
	  f3d_nunchuk_read(&numnum);
	}
      }
      else {
        
      }
    }
  
    // Thermo (Default)
    if (song == 0) {
      printf("\nOpen thermo.wav\n");
      rc = f_open(&fid, "thermo.wav", FA_READ);
      if (rc)
	die(rc);
      
      if (!rc) {
	struct ckhd hd;
	uint32_t  waveid;
	struct fmtck fck;
    
	readckhd(&fid, &hd, 'FFIR');
	
	f_read(&fid, &waveid, sizeof(waveid), &ret);
	if ((ret != sizeof(waveid)) || (waveid != 'EVAW'))
	  return -1;
	
	readckhd(&fid, &hd, ' tmf');
	
	f_read(&fid, &fck, sizeof(fck), &ret);
	
	// skip over extra info
	if (hd.cksize != 16) {
	  printf("extra header info %d\n", hd.cksize - 16);
	  f_lseek(&fid, hd.cksize - 16);
	}

	// now skip all non-data chunks	
	while(1){
	  readckhd(&fid, &hd, 0);
	  if (hd.ckID == 'atad')
	    break;
	  f_lseek(&fid, hd.cksize);
	}
      
	// Start Playing
	f_read(&fid, Audiobuf, AUDIOBUFSIZE, &ret);
	hd.cksize -= ret;
	audioplayerStart(fck.nSamplesPerSec);
	while (hd.cksize) {
	  int next = hd.cksize > AUDIOBUFSIZE/2 ? AUDIOBUFSIZE/2 : hd.cksize;
	  if (audioplayerHalf) {
	    if (next < AUDIOBUFSIZE/2)
	      bzero(Audiobuf, AUDIOBUFSIZE/2);
	    f_read(&fid, Audiobuf, next, &ret);
	    hd.cksize -= ret;
	    audioplayerHalf = 0;
	  }
	  if (audioplayerWhole) {
	    if (next < AUDIOBUFSIZE/2)
	      bzero(&Audiobuf[AUDIOBUFSIZE/2], AUDIOBUFSIZE/2);
	    f_read(&fid, &Audiobuf[AUDIOBUFSIZE/2], next, &ret);
	    hd.cksize -= ret;
	    audioplayerWhole = 0;
	  }
	}
	audioplayerStop();
      }
      printf("\nClose the file.\n"); 
      rc = f_close(&fid);
      if (rc) 
	die(rc);
    }


    // Mario Theme
    if (song == 1) {
      printf("\nOpen start.wav\n");
      rc = f_open(&fid, "thermo.wav", FA_READ);
      if (rc)
	die(rc);
      
      if (!rc) {
	struct ckhd hd;
	uint32_t  waveid;
	struct fmtck fck;
	
	readckhd(&fid, &hd, 'FFIR');
	
	f_read(&fid, &waveid, sizeof(waveid), &ret);
	if ((ret != sizeof(waveid)) || (waveid != 'EVAW'))
	  return -1;
	
	readckhd(&fid, &hd, ' tmf');
	
	f_read(&fid, &fck, sizeof(fck), &ret);
	
	// skip over extra info
	if (hd.cksize != 16) {
	  printf("extra header info %d\n", hd.cksize - 16);
	  f_lseek(&fid, hd.cksize - 16);
	}
	
	// now skip all non-data chunks !	
	while(1){
	  readckhd(&fid, &hd, 0);
	  if (hd.ckID == 'atad')
	    break;
	  f_lseek(&fid, hd.cksize);
	}
	
	// Play it !
	f_read(&fid, Audiobuf, AUDIOBUFSIZE, &ret);
	hd.cksize -= ret;
	audioplayerStart(fck.nSamplesPerSec);
	while (hd.cksize) {
	  int next = hd.cksize > AUDIOBUFSIZE/2 ? AUDIOBUFSIZE/2 : hd.cksize;
	  if (audioplayerHalf) {
	    if (next < AUDIOBUFSIZE/2)
	      bzero(Audiobuf, AUDIOBUFSIZE/2);
	    f_read(&fid, Audiobuf, next, &ret);
	    hd.cksize -= ret;
	    audioplayerHalf = 0;
	  }
	  if (audioplayerWhole) {
	    if (next < AUDIOBUFSIZE/2)
	    bzero(&Audiobuf[AUDIOBUFSIZE/2], AUDIOBUFSIZE/2);
	    f_read(&fid, &Audiobuf[AUDIOBUFSIZE/2], next, &ret);
	    hd.cksize -= ret;
	    audioplayerWhole = 0;
	  }
	}
	audioplayerStop();
	
      }
      printf("\nClose the file.\n"); 
      rc = f_close(&fid);
      if (rc) 
	die(rc);   
    }
    
    // Odyssey Theme
    if (song == 2) {
      printf("\nOpen ammas.wav\n");
      rc = f_open(&fid, "thermo.wav", FA_READ);
      if (rc)
	die(rc);
      
      if (!rc) {
	struct ckhd hd;
	uint32_t  waveid;
	struct fmtck fck;
	
	readckhd(&fid, &hd, 'FFIR');
	
	f_read(&fid, &waveid, sizeof(waveid), &ret);
	if ((ret != sizeof(waveid)) || (waveid != 'EVAW'))
	  return -1;
	
	readckhd(&fid, &hd, ' tmf');
	
	f_read(&fid, &fck, sizeof(fck), &ret);
	
	// skip over extra info
	if (hd.cksize != 16) {
	  printf("extra header info %d\n", hd.cksize - 16);
	  f_lseek(&fid, hd.cksize - 16);
	}

	// now skip all non-data chunks !
	while(1){
	  readckhd(&fid, &hd, 0);
	  if (hd.ckID == 'atad')
	    break;
	  f_lseek(&fid, hd.cksize);
	}

	// Play it !
	f_read(&fid, Audiobuf, AUDIOBUFSIZE, &ret);
	hd.cksize -= ret;
	audioplayerStart(fck.nSamplesPerSec);
	while (hd.cksize) {
	  int next = hd.cksize > AUDIOBUFSIZE/2 ? AUDIOBUFSIZE/2 : hd.cksize;
	  if (audioplayerHalf) {
	    if (next < AUDIOBUFSIZE/2)
	      bzero(Audiobuf, AUDIOBUFSIZE/2);
	    f_read(&fid, Audiobuf, next, &ret);
	    hd.cksize -= ret;
	    audioplayerHalf = 0;
	  }
	  if (audioplayerWhole) {
	    if (next < AUDIOBUFSIZE/2)
	      bzero(&Audiobuf[AUDIOBUFSIZE/2], AUDIOBUFSIZE/2);
	    f_read(&fid, &Audiobuf[AUDIOBUFSIZE/2], next, &ret);
	    hd.cksize -= ret;
	    audioplayerWhole = 0;
	  }
	}
	audioplayerStop();
      }
      printf("\nClose the file.\n"); 
      rc = f_close(&fid);
      if (rc) 
	die(rc);
    }
  }
}


#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
  /* Infinite loop */
  /* Use GDB to find out why we're here */
  while (1);
}
#endif


/* main.c ends here */
