/* main.c ---
* NAME: JUN WANG(wang314)
* PARTNER : 
* lab6
* 
* Created: Thu Jan 10 11:23:43 2013
/* Code: */

#include <stm32f30x.h> // Pull in include files for F30x standard drivers
#include <f3d_led.h> // Pull in include file for the local drivers
#include <f3d_uart.h>
#include <f3d_gyro.h>
#include <f3d_lcd_sd.h>
#include <stdio.h> 



#define TIMER 20000




void lcd_draw_bar(uint16_t color, float f, uint8_t w ) {
  uint8_t x,y;
  f3d_lcd_setAddrWindow (0, w, f, w+5, MADCTLGRAPHICS);
  for (x=0;x< f;x++) {
    for (y=0; y<8 ; y++) {
      f3d_lcd_pushColor(&color,1);
    }
  }
}



int main(void) {
    
  // If you have your inits set up, this should turn your LCD screen red
    f3d_lcd_init();
    f3d_lcd_fillScreen(RED);
    f3d_uart_init();
    f3d_gyro_init();
    
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    
    float b[3];
    
    // limit how many digit we are able to print for the float(b[])
    char string_x[10];
    char string_y[10];
    char string_z[10];
    float one, two , three; 
    
    
    
    while(1) {
        //float b[3];
        
        f3d_gyro_getdata(b);

	  
        char string_x[10];
        char string_y[10];
        char string_z[10];
        
        one = b[0];
	//	printf("%f\n", one);
	if (one >= 0) {
	  sprintf(string_x,"%f", one);
	  f3d_lcd_drawChar( 5, 0, 'X', WHITE, RED );
	  f3d_lcd_drawString( 25, 0, string_x , WHITE, RED );
	  lcd_draw_bar(WHITE, one / 5, 15);
	} else {
	  
	  sprintf(string_x,"%f", one);
	  f3d_lcd_drawChar( 5, 0, 'X', WHITE, RED );
	  f3d_lcd_drawString( 25, 0, string_x , WHITE, RED );
	  one = one * -1;
	  lcd_draw_bar(BLACK, one / 5, 15);
	}
	
	two = b[1];
	if (two >= 0) {
	  sprintf(string_y," %f", two);
	  f3d_lcd_drawChar(5, 50, 'Y', WHITE, RED );
	  f3d_lcd_drawString(25, 50, string_y, WHITE, RED );
	  lcd_draw_bar(WHITE, two/5, 65 ); 
	}else{
	  
	  sprintf(string_y," %f", two);
	  f3d_lcd_drawChar(5, 50, 'Y', WHITE, RED );
	  f3d_lcd_drawString(25, 50, string_y, WHITE, RED );
	  two = two * -1;
	  lcd_draw_bar(BLACK, two/5, 65 );
	}


        three = b[2];
	if (three >= 0) {
	  sprintf(string_z," %f", three);
	  f3d_lcd_drawChar( 5, 100, 'Z', WHITE, RED );
	  f3d_lcd_drawString( 25, 100, string_z , WHITE, RED);  
	  lcd_draw_bar( WHITE, three/5, 115);
	} else {
	  
	  sprintf(string_z," %f", three);
	  f3d_lcd_drawChar( 5, 100, 'Z', WHITE, RED );
	  f3d_lcd_drawString( 25, 100, string_z , WHITE, RED); 
	  three *= -1;  
	  lcd_draw_bar( BLACK, three / 5, 115);
	}
     
	delay(50);
	lcd_draw_bar(RED, one / 5, 15);
	lcd_draw_bar(RED, two / 5, 65 );
	lcd_draw_bar(RED, three / 5, 115 );
      }
}







/*



void delay(int count) {
  while (count-- > 0) {
    int i = 10000; 
    while (i-- > 0) {
      asm("nop");
    }
  }
}

*/

        
#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif

/* main.c ends here */
