/* main.c ---
* Name: JUN WANG(wang314)
* Partner: daozlv
*lab7
* Filename: main.c
* Description:
* Author:
* Maintainer:
* Created: Thu Jan 10 11:23:43 2013
/* Code: */

#include <stm32f30x.h> // Pull in include files for F30x standard drivers
#include <f3d_uart.h>
#include <f3d_user_btn.h>
#include <f3d_lcd_sd.h>
#include <f3d_i2c.h>
#include <f3d_accel.h>
#include <f3d_mag.h>
#include <f3d_delay.h>
#include <stdio.h>
#include <math.h>
#define TIMER 20000

int main(void) {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  
  // Set up your inits before you go ahead
  f3d_delay_init();
  f3d_i2c1_init();
  delay(10);
  f3d_accel_init();
  delay(10);
  f3d_mag_init();
  delay(10);
  f3d_user_btn_init();
  delay(10);
  f3d_uart_init();
  delay(10);
  f3d_led_init();
  delay(10);
  f3d_lcd_init();
  delay(10);
  f3d_lcd_fillScreen(BLUE);

  f3d_led_all_off();
  
  float f[3];
  float x, y ,z; 
  float pitch, roll, heading, xH, yH;
  int usb_factor = 1;
  
  while(1) {
    
    
    //  Tile data--> pitch , roll
    f3d_accel_read(f); 
    x = f[0];
    y = f[1];
    z = f[2];
    //  pitch = atan(   x    / (y^2 + z^2) )^(1/2)
    pitch = atan2f( x,  pow( pow( y, 2.0 ) + pow( z, 2.0 ), 0.5 ) ) ;
    
    //	roll = atan( y / (x^2 + z^2) ^(1/2)
    roll = atan2f( y,  pow( pow( x, 2.0 ) + pow( z, 2.0 ), 0.5 ) ) ;
    
    // Compass data --> xh, yh, heading
    f3d_mag_read(f);
    x = f[0];
    y = f[1];
    z = f[2];
    // xH = X * cos(pitch) + z * sin(pitch)	
    xH = x * cosf(pitch) + z *sinf(pitch);
    
    // yh = x * sin(roll) * sin(pitch) + (y*cos(roll)) - (z * sin(roll) * cos(pitch))
    yH = x * sinf(roll) * sinf(pitch) + (y * cosf(roll)) - (z * sin(roll) * cos(pitch) );
    // heading = (atan2(yh, xh) * 180 ) /M_PI
    heading = atan2f(yH, xH) * 180 /M_PI;

    //setting userbutton
    if(user_btn_read()) {
      printf("Clicked\n");
      usb_factor += 1;
      usb_factor = usb_factor % 2;
      delay(100);
    }
    
    if(usb_factor == 1) { // into compass mode

      printf("Mode 1\n");
      
      // compass visualizaion --> use led to visualize the north direction
      //range for heading is -135~135 --34  
      //want the lcd light always point to north
      if(heading >= -157.5 && heading < -114.5)
	f3d_led_on(0);
      if(heading >= -114.5 && heading < -67.5)
	f3d_led_on(7);
      if(heading >= -67.5 && heading < -22.5)
	f3d_led_on(6);
      if(heading >= -22.5 && heading < 22.5)
	f3d_led_on(5);
      if(heading >= 22.5 && heading < 67.5)
	f3d_led_on(4);
      if(heading >= 67.5 && heading < 114.5)
	f3d_led_on(3);
      if(heading >= 114.5 && heading < 157.5)
	f3d_led_on(2);
      if(heading >= 157.5 || heading < -157.5)
	f3d_led_on(1);

      delay(50);
      f3d_led_all_off();
    } 
    
    if ( usb_factor == 0 ) { // into another mode

      int mx = ST7735_width / 2 + roll * 2 / M_PI * ST7735_width / 2;
      int my = ST7735_height / 2 + pitch * 2 / M_PI * ST7735_height / 2;
      
      int i;
      for(i = 0; i < 3; i++) {
	f3d_lcd_drawPixel(mx - i, my - i, WHITE);
	f3d_lcd_drawPixel(mx - i, my + i, WHITE);
	f3d_lcd_drawPixel(mx + i, my - i, WHITE);
	f3d_lcd_drawPixel(mx + i, my + i, WHITE);
      }
      delay(100);
      for(i = 0; i < 3; i++) {
	f3d_lcd_drawPixel(mx - i, my - i, BLUE);
	f3d_lcd_drawPixel(mx - i, my + i, BLUE);
	f3d_lcd_drawPixel(mx + i, my - i, BLUE);
	f3d_lcd_drawPixel(mx + i, my + i, BLUE);
      }
    } 
  } // close while loop
}




#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif

/* main.c ends here */
