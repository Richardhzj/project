//NAME : JUN WANG (wang314)
//PARTNER:Isaac Fisch; Quintin Lepper

#include <stdio.h>

void mywc(void) {
  int c;
  
  int countLine, countWord, countChar;
  
  countLine =1;
  countWord = 1;
  countChar = 0;
  
  while((c = getchar()) != 27) {
    printf("%c", c);
    if ((c != ' ') && (c != '\n') &&  (c == '\t') && (c == '\r') && (c == '\f')&& (c == '\v' ))
    	countChar++; 
    
    if ((c == ' ') || (c == '\n') || (c == '\t') ||(c == '\r') || (c == '\f')|| (c == '\v' ))
      countWord++;
      
    if (c == '\n')
      countLine++;

    //Printing info
    //printf("Lines : %d, Words: %d, Char: %d\n", countLine, countWord, countChar);
    
  }

  printf("%c\n", c); // if whant to print with this line then is not work
  printf("\n");
  printf("Lines : %d \n", countLine );
  printf("Words : %d \n" , countWord );
  printf("Characters : %d \n", countChar) ;	
}
