void mywc(void);
