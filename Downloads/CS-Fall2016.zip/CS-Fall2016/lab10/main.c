/********************************************************** 
 * main.c 
 * 
 * initialize and print typed characters
 * 
 *   Author: Samuel Eleftheri - selefthe
 *           Jun Wang - wang314
 *   Date Created: November 5th, 2016
 *   Last Modified by: NA 
 *   Date Last Modified: NA 
 *   Assignment: main.c 
 *   Part of: lab10
 */ 

#include <stm32f30x.h>
#include <stm32f30x_misc.h>
#include <f3d_systick.h>
#include <f3d_led.h>
#include <f3d_delay.h>
#include <f3d_uart.h>
#include <f3d_user_btn.h>
#include <queue.h>
#include <stdio.h>
#include <stdlib.h>
#define TIMER 20000

int main(void) {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  f3d_uart_init();
  delay(100);
  f3d_delay_init();
  delay(100);
  f3d_led_init();
  delay(100);
  f3d_user_btn_init();
  delay(100);
  f3d_systick_init();

  while(1) {
    putchar(getchar());
  }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
  /* Infinite loop */
  /* Use GDB to find out why we're here */
  while (1);
}
#endif
