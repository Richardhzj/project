/* main.c ---
* NAME: JUN WANG (wang314)
* PARTNER: 
*
*
* 
* 
* 
/* Code: */

#include <stm32f30x.h> // Pull in include files for F30x standard drivers
#include <f3d_led.h> // Pull in include file for the local drivers
#include <f3d_uart.h>
#include <f3d_gyro.h>
#include <f3d_lcd_sd.h>
#include <stdio.h>
// #define TIMER 20000// --? any relation with delay?

void delay(void){
	int i = 2000000;
	while( i-- > 0){
		asm("nop");
	}
 }




int main(void) {
	
	f3d_led_init();
	f3d_uart_init();

       	setvbuf(stdin, NULL, _IONBF, 0);
       	setvbuf(stdout, NULL, _IONBF, 0);
       	setvbuf(stderr, NULL, _IONBF, 0);

	while(1) {
	 
	  f3d_led_on(1);	
	  printf(" all light on ");    	
	  delay();
	  f3d_led_off(1); 
	  printf(" all light off ");
	  delay();
   } 
}


        
#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif

/* main.c ends here */
