/************************** 
 *f3d_uart.c 
 *contains the initialization basic i/o functions for UART
****************************/ 

/* Code: */

#include <stm32f30x.h>
#include <f3d_uart.h>
//the initialization function to call
void f3d_uart_init(void) {

  
}
//sends a character
int putchar(int c) {
} 
//gets a character
int getchar(void) {
}
//sends a string
void putstring(char *s) {
}



/* f3d_uart.c ends here */
