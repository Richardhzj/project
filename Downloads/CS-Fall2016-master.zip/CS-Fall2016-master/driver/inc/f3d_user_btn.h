/* 
John Schneider
Xhenjiang
lab3
declarations for f3d_user_btn.c */


void f3d_user_btn_init(void);
int f3d_user_btn_read(void);

