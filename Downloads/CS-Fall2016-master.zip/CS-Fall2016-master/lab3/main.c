#include <stm32f30x.h>  // Pull in include files for F30x standard drivers 
#include <f3d_led.h>     // Pull in include file for the local drivers
#include <f3d_user_btn.h>

/*
John Schneider
Zhengjia
Lab2
9.15.2016
*/

// Simple looping delay function
void delay(void) {
  int i = 2000000;
  while (i-- > 0) {
    asm("nop"); /* This stops it optimising code out */
  }
}



int main(void) {
  
  int j = 0;
  //Simple loop that lights based off of j

  while(1){

  f3d_led_init();
  f3d_user_btn_init();
  if(j == 0){
    f3d_led_all_on();
    delay();
    j++;
    delay();
  }


   f3d_led_all_off();
   f3d_led_on(j);
   delay();
   j++;
   delay();
   f3d_led_all_off();
   //checks if button is pushed
   while(user_btn_read()){
     f3d_led_all_on();
    }
   if(j>7){
     j=0;
     }
   }

}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line) {
/* Infinite loop */
/* Use GDB to find out why we're here */
  while (1);
}
#endif

/* main.c ends here */
