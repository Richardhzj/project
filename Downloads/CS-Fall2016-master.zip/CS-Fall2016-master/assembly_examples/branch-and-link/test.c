int foo(int i){
  return i+1;
}

int bar(int i) {
  return foo(i);
}
