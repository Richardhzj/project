//Troy Smith, smithtro
//partners with Andrew Messer, ajmesser

/**********************************
 *f3d_user_btn.c 
 *contains the init and read functions for the User Button
 *********************************/
#include <stm32f30x.h>
#include <stm32f30x_gpio.h>
#include <stm32f30x_rcc.h>


/*Initialization of the UserButton*/
void user_btn_init(void){
  GPIO_InitTypeDef GPIO_InitStructure;//instantiates the GPIO structure
  GPIO_StructInit(&GPIO_InitStructure);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;//pin 0 refers to the user button pin
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;//specifies user button as inputting something
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);//initializes the port A clock
  GPIO_Init(GPIOA, &GPIO_InitStructure);//initializes the GPIO structure
}

/*reads the User Button*/
int user_btn_read(void){
  return GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0);//simply returns either a 1 (true) or 0 (false) referring to whether or not the button has been pushed down 
}
