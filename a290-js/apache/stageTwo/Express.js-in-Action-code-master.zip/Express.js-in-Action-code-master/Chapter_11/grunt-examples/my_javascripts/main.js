var randomString = require("random-string");

console.log(randomString({ length: 10 }));
